# MNTZ AI subscription integration

## Product decision
- MNTZ AI Free: limited quota (the exact daily cap is a product decision still to be made).
- MNTZ AI Pro: USD $15 per month.

## Required production flow
1. User signs in; backend creates/loads a stable user ID.
2. App asks backend to create a checkout session.
3. Provider hosts checkout; app opens the returned checkout URL.
4. Provider sends a signed webhook to the backend after payment/renewal/cancellation.
5. Backend verifies the webhook signature and updates subscription state in the database.
6. App requests `/api/me/subscription`; backend returns `free` or `pro`, renewal date, and status.
7. Backend enforces usage quotas on every AI request. The app must never be trusted to grant Pro.

## Not enabled yet
No payment provider, merchant account, webhook secret, database, authentication, or live checkout has been configured. The current app's subscribe button is a demo notice only and does not charge the user or unlock Pro.

## Before choosing a provider
Confirm that the provider supports the merchant's country, business type, payout bank, recurring USD billing, refunds, and webhook signatures. Do not collect card numbers directly in MNTZ AI.
