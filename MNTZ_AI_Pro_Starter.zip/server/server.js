import "dotenv/config";
import express from "express";
import cors from "cors";
import Anthropic from "@anthropic-ai/sdk";

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));

const apiKey = process.env.ANTHROPIC_API_KEY;
const client = apiKey ? new Anthropic({ apiKey }) : null;

app.get("/health", (_req,res)=>res.json({ok:true,service:"MNTZ AI"}));

app.post("/api/chat", async (req,res) => {
  try {
    if (!client) return res.status(503).json({error:"أضف ANTHROPIC_API_KEY إلى ملف .env في الخادم أولاً."});
    const incoming = req.body?.messages;
    if (!Array.isArray(incoming) || incoming.length === 0) return res.status(400).json({error:"أرسل رسالة صحيحة."});
    const messages = incoming.slice(-30).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0,12000)
    })).filter(m=>m.content.trim());
    const result = await client.messages.create({
      model: "claude-3-5-haiku-latest",
      max_tokens: 1200,
      system: "أنت MNTZ AI، مساعد ذكي وودود. أجب بلغة المستخدم، واستخدم العربية عند التحدث بالعربية. كن واضحاً ودقيقاً.",
      messages
    });
    const reply = (result.content || []).filter(c=>c.type==="text").map(c=>c.text).join("\n");
    res.json({reply});
  } catch (err) {
    console.error(err);
    res.status(500).json({error:"تعذر إنشاء الرد. تحقق من مفتاح API والاتصال وحدود الاستخدام."});
  }
});

const port = Number(process.env.PORT || 8787);
app.listen(port, "0.0.0.0", ()=>console.log(`MNTZ AI server running on ${port}`));
