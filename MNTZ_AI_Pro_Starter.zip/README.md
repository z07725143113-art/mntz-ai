# MNTZ AI — Android starter

MNTZ AI is an Arabic-first AI chat app starter with a Claude-inspired (not copied) clean interface.

## What is included
- Expo / React Native Android app (RTL Arabic chat UI)
- Node.js backend proxy for Anthropic Claude Messages API
- Chat history stored locally on the device
- Streaming is not enabled in this starter; responses are returned as a complete message

## Requirements
- Node.js 18+
- Expo Go for quick testing, or EAS Build for an installable Android APK/AAB
- An Anthropic API key

## 1) Configure the backend
```bash
cd server
cp .env.example .env
# Put your key in ANTHROPIC_API_KEY
npm install
npm start
```
The backend listens on port 8787. For a physical phone, set `EXPO_PUBLIC_API_URL` to your computer's LAN IP, e.g. `http://192.168.1.10:8787`.

## 2) Run the Android app
```bash
cd mobile
npm install
npx expo start
```
Scan the QR code with Expo Go. Ensure phone and computer are on the same Wi-Fi.

## 3) Build an Android install
Install EAS CLI and sign in:
```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```
The EAS build service produces an installable APK when configured with the preview profile below.

## Important security notes
- Never put the Anthropic API key in the Android app.
- Keep the key only in the backend `.env` file.
- This project is a starter, not a published app. You must configure hosting, privacy policy, app signing, and API billing/limits before public release.
- Claude API usage may incur charges according to Anthropic's current pricing and account terms.


## Subscription model (configured in the Android UI)
- Free: introductory limited usage (enforcement still needs server-side quotas).
- MNTZ AI Pro: **USD $15 / month**.
- The app includes a plan-selection screen and a clearly labelled subscribe action.
- The subscribe action is intentionally a non-charging placeholder until a payment provider is selected and integrated.
- Never unlock Pro based only on a client-side button press. Verify successful payments server-side using signed provider webhooks, then store subscription state against the authenticated user.
- Before launch, define exact message/file limits, cancellation/refund terms, taxes, and supported countries/payment methods.
