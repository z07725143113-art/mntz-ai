import React, { useEffect, useRef, useState } from "react";
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList, KeyboardAvoidingView, Platform, ActivityIndicator, Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { StatusBar } from "expo-status-bar";

const API_URL = process.env.EXPO_PUBLIC_API_URL || "http://10.0.2.2:8787";
const COLORS = { bg:"#F7F6F2", ink:"#25231F", muted:"#858078", line:"#E8E5DE", orange:"#D97757", card:"#FFFFFF" };

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [showPlans, setShowPlans] = useState(false);
  const list = useRef(null);

  useEffect(() => { AsyncStorage.getItem("mntz_history").then(v => { if(v) setMessages(JSON.parse(v)); }); }, []);
  useEffect(() => { AsyncStorage.setItem("mntz_history", JSON.stringify(messages)).catch(()=>{}); }, [messages]);

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    const next = [...messages, { role:"user", content:text, id:Date.now()+"u" }];
    setMessages(next); setInput(""); setBusy(true);
    try {
      const response = await fetch(`${API_URL}/api/chat`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({ messages: next.map(m=>({role:m.role,content:m.content})) })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر الاتصال بالخادم");
      setMessages(prev=>[...prev,{role:"assistant",content:data.reply,id:Date.now()+"a"}]);
    } catch(e) {
      setMessages(prev=>[...prev,{role:"assistant",content:`حدث خطأ: ${e.message}\n\nتأكد من تشغيل الخادم وضبط عنوانه.`,id:Date.now()+"e"}]);
    } finally { setBusy(false); }
  }

  function clearChat() {
    Alert.alert("محادثة جديدة","هل تريد حذف المحادثة الحالية؟",[
      {text:"إلغاء",style:"cancel"},
      {text:"حذف",style:"destructive",onPress:()=>setMessages([])}
    ]);
  }

  const renderMessage = ({item}) => {
    const user = item.role === "user";
    return <View style={{alignSelf:user?"flex-end":"stretch",maxWidth:user?"88%":"100%",marginVertical:9,marginHorizontal:user?12:0}}>
      {user ? <View style={{backgroundColor:"#EEECE6",padding:14,borderRadius:20,borderTopRightRadius:5}}>
        <Text style={{color:COLORS.ink,fontSize:16,lineHeight:25,textAlign:"right"}}>{item.content}</Text>
      </View> : <View style={{paddingHorizontal:4,paddingVertical:5}}>
        <View style={{flexDirection:"row",alignItems:"center",marginBottom:7}}>
          <View style={{width:25,height:25,borderRadius:9,backgroundColor:"#F1DDD4",alignItems:"center",justifyContent:"center"}}><Text style={{color:COLORS.orange,fontWeight:"800"}}>M</Text></View>
          <Text style={{marginLeft:8,fontWeight:"700",color:COLORS.ink}}>MNTZ AI</Text>
        </View>
        <Text style={{color:COLORS.ink,fontSize:16,lineHeight:27,textAlign:"right"}}>{item.content}</Text>
      </View>}
    </View>;
  };

  return <SafeAreaView style={{flex:1,backgroundColor:COLORS.bg}}>
    <StatusBar style="dark"/>
    <View style={{height:58,paddingHorizontal:18,flexDirection:"row",alignItems:"center",justifyContent:"space-between",borderBottomWidth:1,borderColor:COLORS.line}}>
      <TouchableOpacity onPress={clearChat}><Text style={{fontSize:14,color:COLORS.muted}}>محادثة جديدة</Text></TouchableOpacity>
      <View style={{alignItems:"flex-end"}}>
        <Text style={{fontSize:19,fontWeight:"800",color:COLORS.ink}}>MNTZ AI</Text>
        <Text style={{fontSize:10,color:COLORS.muted}}>مساعدك الذكي</Text>
      </View>
      <TouchableOpacity onPress={()=>setShowPlans(true)} style={{backgroundColor:"#F1DDD4",paddingHorizontal:11,paddingVertical:7,borderRadius:14}}><Text style={{color:COLORS.orange,fontWeight:"700",fontSize:12}}>ترقية Pro</Text></TouchableOpacity>
    </View>
    {showPlans ? <View style={{flex:1,padding:22,justifyContent:"center"}}>
      <TouchableOpacity onPress={()=>setShowPlans(false)} style={{alignSelf:"flex-start",padding:8}}><Text style={{color:COLORS.muted,fontSize:15}}>رجوع ←</Text></TouchableOpacity>
      <Text style={{fontSize:29,fontWeight:"800",color:COLORS.ink,textAlign:"right",marginTop:18}}>اختر خطتك</Text>
      <Text style={{fontSize:15,color:COLORS.muted,textAlign:"right",marginTop:8,lineHeight:24}}>ابدأ مجاناً، أو افتح مزايا MNTZ AI Pro.</Text>
      <View style={{backgroundColor:"#FFFFFF",borderWidth:1,borderColor:COLORS.line,borderRadius:22,padding:18,marginTop:22}}>
        <Text style={{fontSize:19,fontWeight:"800",color:COLORS.ink,textAlign:"right"}}>Free</Text>
        <Text style={{fontSize:27,fontWeight:"800",color:COLORS.ink,textAlign:"right",marginTop:8}}>مجاناً</Text>
        {["عدد محدود من الرسائل","محادثات نصية أساسية","سجل محادثات على جهازك"].map(x=><Text key={x} style={{textAlign:"right",color:COLORS.muted,marginTop:12}}>✓  {x}</Text>)}
        <Text style={{fontSize:12,color:COLORS.muted,textAlign:"right",marginTop:16}}>الخطة الحالية عند بدء الاستخدام</Text>
      </View>
      <View style={{backgroundColor:"#292722",borderRadius:22,padding:19,marginTop:14}}>
        <View style={{flexDirection:"row",justifyContent:"space-between",alignItems:"center"}}>
          <View style={{backgroundColor:"#D97757",paddingHorizontal:10,paddingVertical:5,borderRadius:10}}><Text style={{color:"white",fontWeight:"800",fontSize:11}}>الأكثر اختياراً</Text></View>
          <Text style={{fontSize:20,fontWeight:"800",color:"#FFFFFF"}}>MNTZ AI Pro</Text>
        </View>
        <View style={{flexDirection:"row",justifyContent:"flex-end",alignItems:"baseline",marginTop:12}}>
          <Text style={{fontSize:14,color:"#D9D4CB"}}> / شهرياً</Text>
          <Text style={{fontSize:35,fontWeight:"900",color:"#FFFFFF"}}>$15</Text>
        </View>
        {["حدود استخدام أعلى","الوصول إلى نماذج ذكاء اصطناعي أقوى حسب الإعداد","رفع ملفات وتحليلها عند تفعيل الميزة","أولوية في معالجة الطلبات حسب التوفر"].map(x=><Text key={x} style={{textAlign:"right",color:"#F0ECE5",marginTop:12,fontSize:14}}>✓  {x}</Text>)}
        <TouchableOpacity onPress={()=>Alert.alert("الاشتراك غير مفعّل بعد","تم اعتماد سعر Pro وهو 15 دولاراً شهرياً. يجب ربط بوابة دفع وخادم تحقق آمن قبل تحصيل أي مبلغ.")} style={{backgroundColor:"#D97757",borderRadius:15,padding:14,marginTop:20,alignItems:"center"}}>
          <Text style={{color:"white",fontWeight:"800",fontSize:16}}>اشترك الآن — $15 / شهر</Text>
        </TouchableOpacity>
      </View>
      <Text style={{fontSize:11,color:COLORS.muted,textAlign:"center",marginTop:14,lineHeight:18}}>لن يتم خصم أي مبلغ حالياً. الدفع وتفعيل العضوية يحتاجان ربط بوابة دفع والتحقق من العملية على الخادم.</Text>
    </View> : <KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==="ios"?"padding":undefined} keyboardVerticalOffset={8}>
      {messages.length===0 ? <View style={{flex:1,justifyContent:"center",alignItems:"center",padding:26}}>
        <View style={{width:58,height:58,borderRadius:20,backgroundColor:"#F1DDD4",alignItems:"center",justifyContent:"center",marginBottom:22}}><Text style={{fontSize:28,color:COLORS.orange,fontWeight:"800"}}>M</Text></View>
        <Text style={{fontSize:27,fontWeight:"700",color:COLORS.ink,textAlign:"center",marginBottom:10}}>أهلاً بك، كيف أساعدك؟</Text>
        <Text style={{fontSize:15,color:COLORS.muted,textAlign:"center",lineHeight:24}}>اسأل عن أي شيء، أو اطلب مني الكتابة أو التفكير أو البرمجة.</Text>
      </View> : <FlatList ref={list} data={messages} keyExtractor={m=>m.id} renderItem={renderMessage} contentContainerStyle={{padding:16,paddingBottom:25}} onContentSizeChange={()=>list.current?.scrollToEnd({animated:true})}/>}
      {busy && <View style={{paddingHorizontal:20,paddingBottom:10,flexDirection:"row",alignItems:"center",justifyContent:"flex-end"}}><ActivityIndicator color={COLORS.orange}/><Text style={{color:COLORS.muted,marginRight:9}}>MNTZ AI يكتب...</Text></View>}
      <View style={{paddingHorizontal:12,paddingTop:8,paddingBottom:10,borderTopWidth:1,borderColor:COLORS.line}}>
        <View style={{backgroundColor:COLORS.card,borderWidth:1,borderColor:"#E2DED6",borderRadius:24,padding:8,flexDirection:"row",alignItems:"flex-end"}}>
          <TouchableOpacity onPress={send} disabled={busy||!input.trim()} style={{width:42,height:42,borderRadius:16,backgroundColor:busy||!input.trim()?"#D9D5CE":COLORS.ink,alignItems:"center",justifyContent:"center"}}>
            <Text style={{color:"white",fontSize:20,fontWeight:"700"}}>↑</Text>
          </TouchableOpacity>
          <TextInput value={input} onChangeText={setInput} placeholder="اكتب رسالتك إلى MNTZ AI..." placeholderTextColor="#A29D94" multiline textAlign="right" style={{flex:1,maxHeight:120,minHeight:42,paddingHorizontal:12,paddingTop:10,color:COLORS.ink,fontSize:15}}/>
        </View>
        <Text style={{textAlign:"center",fontSize:10,color:COLORS.muted,marginTop:7}}>قد يخطئ MNTZ AI، تحقق من المعلومات المهمة.</Text>
      </View>
    </KeyboardAvoidingView>}
  </SafeAreaView>;
}
